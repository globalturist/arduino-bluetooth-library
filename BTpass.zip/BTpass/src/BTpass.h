/*|------------------------------------------------------------------------------------------------------------|*/
/*| BTPL: specifies the length of both the correct password and the entered password (changable from 1 to 65)  |*/
/*| max is 65 because the serial buffer can hold only upto 64 bytes + 1 byte at the end of the string is the   |*/
/*| NULL terminator                                                                                            |*/
/*| WRONG: displayed when a wrong password is entered                                                          |*/
/*| CORRECT: displayed when a right password is entered                                                        |*/
/*| TRIES: displayed when wrong password is entered and _tries gets decremented                                |*/
/*| PASS: displayed when ready to read password                                                                |*/
/*| OOT: displayed when you are out of tries                                                                   |*/
/*|                                 ___ALL OF THE ABOVE IS CHANGABLE___                                        |*/
/*|                                                                                                            |*/
/*| Ways to initiate an object:                                                                                |*/
/*|                                                                                                            |*/
/*| BT bluePass("pass",tries);                                                                                 |*/
/*| parameters:                                                                                                |*/
/*| "pass" : password of your choice in between ""                                                             |*/
/*| tries : amount of tries of your choice (max 255, 0 or negative values will be set to 1 automatically)      |*/
/*| noCase and feedBack will be set to false by default in this constructor                                    |*/
/*|                                                                                                            |*/
/*| BT bluePass("pass",tries,noCase,feedBack);                                                                 |*/
/*| "pass" : same as above                                                                                     |*/
/*| tries  : same as above                                                                                     |*/
/*| noCase : if set to false will take in account both lower and upper case characters. if set to true will    |*/
/*| ignore upper case and transform both correct password and entered password to lower case                   |*/
/*| feedBack: if set to false will not display any messages from the defines below. if set to true will        |*/
/*| display defines below at propper times                                                                     |*/
/*|                                                                                                            |*/
/*| how to use:                                                                                                |*/
/*|                                                                                                            |*/
/*| call the following method on an object:                                                                    |*/
/*| BT blue("1234",3);                                                                                         |*/
/*| if(blue.requestPassword()) {                                                                               |*/
/*|   //do something                                                                                           |*/
/*| }                                                                                                          |*/
/*|                                                                                                            |*/
/*| requestPassword()                                                                                          |*/
/*| -----------------                                                                                          |*/
/*| parameters: none                                                                                           |*/
/*| returns: true if the correct password is entered and not out of tries. false if you entered the wrong      |*/
/*| password multiple times and you are out of tries                                                           |*/
/*|------------------------------------------------------------------------------------------------------------|*/

#ifndef BT_PASS
#define BT_PASS

#if defined(ARDUINO_ARCH_AVR)

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

#define BTPL 65 //maximum value. decrease size to save some SRAM (remember to calculate the following: the password length + 1 for the NULL terminator).
#define WRONG   "Wrong password try again"
#define CORRECT "Correct password"
#define TRIES   "Tries left: "                //all of the strings use F() macros therefore no SRAM is used.
#define PASS    "Enter the password:"
#define OOT     "You're out of tries"

class BT {
  private:
    //private variables
    uint8_t _correctPassword[BTPL];
    uint8_t _enteredPassword[BTPL];
    uint8_t _tries;
    bool    _noCase;
    bool    _feedBack;

    //private functions
    void    convertToLower(uint8_t (&arr)[BTPL]);
    void    flushSerialBuffer();
    void    clearPassword();
    void    readPassword(); 
    bool    checkPass();
  public:
    //public constructors
    BT(uint8_t pass[BTPL], uint8_t tries, bool noCase, bool feedBack);
    BT(uint8_t pass[BTPL], uint8_t tries);

    //public functions
    bool requestPassword();
};//End of BT class

#else
  #error �This library only supports boards with an AVR processor.�

#endif
#endif
