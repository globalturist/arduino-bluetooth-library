#include "BTpass.h"

/*------PRIVATE-SECTION-START------*/
void BT::convertToLower(uint8_t (&arr)[BTPL]){
  for(uint8_t i{0};i<BTPL;i++)
    if((arr[i] >= 'A') && (arr[i] <= 'Z')) arr[i] = arr[i] + 0x20;
}//End of convertToLower function

inline void BT::flushSerialBuffer(){ while(Serial.available()>0) (void)Serial.read(); }

inline void BT::clearPassword(){ for(uint8_t i{0};i<BTPL;i++) _enteredPassword[i] = ' '; }

void BT::readPassword(){
 uint8_t i{0};
 bool flag{false};
 if(_feedBack) Serial.println(F(PASS));
 while(!Serial.available());
 do{
   if(Serial.available() > 0){
     _enteredPassword[i] = Serial.read();
     delay(10);
     if(Serial.available() <= 0) {
      flag = true;
      _enteredPassword[i+1] = NULL;
     }//if end
     else {
      i++;
      if(i == (BTPL-1)) flag = true; 
     }//else end
   }//if end
 }while(!flag);
 if(_noCase) convertToLower(_enteredPassword);
 flushSerialBuffer();
}//End of readPassword function

bool BT::checkPass(){
  uint8_t i{0};
  while(_enteredPassword[i]==_correctPassword[i]){
    i++;
    if((_enteredPassword[i]==NULL)&&(_correctPassword[i]==NULL)) return true;
  }//while end
  return false;
}//End of checkPass function
/*-------PRIVATE-SECTION-END-------*/

/*------PUBLIC-SECTION-START-------*/
BT::BT(uint8_t pass[BTPL], uint8_t tries, bool noCase, bool feedBack) : _tries{tries}, _noCase{noCase}, _feedBack{feedBack} {
  strcpy(_correctPassword,pass);
  if(_noCase) convertToLower(_correctPassword); 
  if(_tries<=0) _tries = 1;
}//End of BT constructor

BT::BT(uint8_t pass[BTPL], uint8_t tries) : _tries{tries}, _noCase{false}, _feedBack{false} { 
  strcpy(_correctPassword,pass);
  if(_tries<=0) _tries = 1;
}//End of BT constructor

bool BT::requestPassword(){
  do{
    readPassword();
    if(checkPass()){
      if(_feedBack) Serial.println(F(CORRECT)); 
      return true;
    }//if end
    else {
      clearPassword();
      _tries--;
      if(_feedBack){
        Serial.println(F(WRONG));
        Serial.print(F(TRIES));
        Serial.print(_tries);
        Serial.print('\n');
      }//if end
    }//else end
  }while(_tries > 0);
  if(_feedBack) Serial.println(F(OOT));
  return false;
}//End of requestPassword function
/*-------PUBLIC-SECTION-END-------*/


